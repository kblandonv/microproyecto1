/* Therapy_SE
 * Sistema experto de recomendación de soluciones para un nivel de ansiedad y un grado de TOC dados
 * 
 * 
 * Por:
 *     Daniel Santiago Cadavid Montoya 
 * 	   Juan Esteban Ochoa Gomez
 *     Marlon Calle Areiza
*/

%Se comienza planteando la parte principal en donde se escriben
%las variables y se llama a la implicación recomendar.
%Primero se recibe la variable <TOC>, relacionada al grado de TOC del paciente,
%esta variable espera recibir valores x entre [1,10] con x entero.
%Luego se recibe la variable <Ansiedad> relacionada al nivel de ansieda del paciente,
%esta variable espera recibir valores u entre [1,10] con u entero.
sugerir(Terapia) :- 
    write('Ingrese el grado de TOC como un número entero entre 0 y 10 inclusives'
          ), read(TOC),
    write('Ingrese el nivel de ansiedad como un número entero entre 0 y 10 inclusives'
          ), read(Ansiedad),
    write('Te recomendamos lo siguiente'),
    recomendar(Terapia,Ansiedad,TOC).

%A continuación se plantean las diferentes soluciones a recomendar en la implicación correspondiente
%Cada recomendación se hace de acuerdo al nivel de ansiedad y grado de TOC del paciente

%Para casos en los que el paciente tenga un grado de TOC relativamente bajo y queramos concentrarnos
%en las recomendaciones para ansiedad
recomendar("Se recomiendan actividades de relajación como caminar, pintar o escribir para la prevención en ansiedad del tipo leve",
           Ansiedad,TOC):- Ansiedad=<3, TOC=<2,!.

recomendar("Se recomienda comenzar el uso de benzodiazepina ansiolítica para tratar los síntomas de ansiedad leve físicos",
           Ansiedad, TOC):-Ansiedad>3,Ansiedad=<5,TOC=<2,!.

recomendar("Se recomienda comenzar el uso de inhibidores del tipo ISRS como manera preventiva",
           Ansiedad, TOC):-Ansiedad>5, Ansiedad=<7,TOC=<2,!. 

recomendar("Se recomienda una internación preventiva para evitar daños físicos al paciente implicado, además de una cita con un especialista lo más pronto posible",
           Ansiedad, TOC):- Ansiedad>7, TOC=<2,!.

%Para casos en los que el paciente tenga un nivel de ansiedad relativamente bajo y queramos
%concentrarnos en las recomendaciones para TOC:
recomendar("Se recomiendan ejercicios de relajación como pintura o escritura que para prevenir la agravación de síntomas de TOC",
           Ansiedad,Toc):- Toc=<4,Ansiedad=<3,!.

recomendar("Se recomienda iniciar terapia psicológica de hasta mínimo 10 horas con un terapeuta especializado para confrontar las causas que puedan generar estas obsesiones",
           Ansiedad,Toc):- Toc=<7, Ansiedad=<3, !.

recomendar("Se recomienda comenzar el uso de inhibidores ISRS para aumentar los niveles de serotonina y ayudar a mejorar los síntomas relacionados al TOC",
           Ansiedad,Toc):- Toc>7, Toc=<9,Ansiedad=<5,!.

recomendar("Se recomienda en primera instancia un internamiento preventivo pero si no presenta mejoría, se debería estudiar la posibilidad de realizar una estimulación cerebral profunda",
           Ansiedad,Toc):- Toc>9,Ansiedad=<5,!.

%Para casos en los que el paciente tenga un nivel de Ansiedad y un grado de TOC más 
%que bajos
recomendar("Se recomienda el uso de algunos antidepresivos como ISRS, en caso de que el paciente sea resistente se recomienda terapia CBT",
           Ansiedad,Toc):-Toc>2, Toc=<7, Ansiedad=<7,  Ansiedad>3, !.
    
recomendar("Se recomienda el uso de antihistaminicos como buspirona que genera menor dependencia y etifoxina enfocada en los efectos psicosomáticos de los DM",
           Ansiedad,Toc):-Toc>2, Toc=<7, Ansiedad>7, Ansiedad=<9, !.

recomendar("Se recomienda el uso de antihistaminicos como buspirona que genera menor dependencia y etifoxina enfocada en los efectos psicosomáticos de los DM, además se recomienda comenzar terapia con un especialista",
           Ansiedad,Toc):-Toc>7, Toc=<9, Ansiedad>7, Ansiedad=<9, !.

recomendar("Se recomienda estudiar el uso de antipsicóticos atípicos además de internación preventiva para evitar daños físicos del implicado",
           Ansiedad,Toc):-  Ansiedad>9,Toc>9,!.

recomendar("Se recomienda estudiar el uso de antipsicóticos atípicos además de internación preventiva para evitar daños físicos del implicado",
           Ansiedad,Toc):- Toc>2, Toc=<7,Ansiedad>9,!.

recomendar("Se recomienda estudiar el uso de antipsicóticos atípicos además de internación preventiva para evitar daños físicos del implicado",
           Ansiedad,Toc):- Toc>9,Ansiedad>7, Ansiedad=<9,!.

recomendar("Por el momento el SE no tiene recomendaciones para su caso conjunto, pero puede estudiar la ansiedad y el TOC por separado y estudiar las conclusiones",
           Ansiedad,_):-Ansiedad=<20,!.