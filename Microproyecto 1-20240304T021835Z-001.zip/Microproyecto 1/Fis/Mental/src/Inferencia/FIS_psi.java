package Inferencia;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;

public class FIS_psi {
	private static float frec_mismo_pensamiento;
	private static float indisp_fallar_obj;
	private static float r_sensacion_asfixia;

	public FIS_psi(float frec_mismo_pensamiento, float indisp_fallar_obj, float r_sensacion_asfixia) {
		FIS_psi.frec_mismo_pensamiento = frec_mismo_pensamiento;
		FIS_psi.indisp_fallar_obj = indisp_fallar_obj;
		FIS_psi.r_sensacion_asfixia = r_sensacion_asfixia;
	}

	public static String calculateFCL() {
		// Carga el archivo de lenguaje de control difuso 'FCL'
		String fileName = "src/Inferencia/FCL_psi.fcl";
		FIS fis = FIS.load(fileName, true);

		// En caso de error
		if (fis == null) {
			System.err.println("No se puede cargar el archivo: '" + fileName + "'");
			return "";
		}

		// Establecer las entradas del sistema
		fis.setVariable("frec_mismo_pensamiento", frec_mismo_pensamiento);
		fis.setVariable("indisp_fallar_obj", indisp_fallar_obj);
		fis.setVariable("r_sensacion_asfixia", r_sensacion_asfixia);

		// Inicia el funcionamiento del sistema
		fis.evaluate();

		//Muestra los gráficos de las variables de entrada y salida
		JFuzzyChart.get().chart(fis.getFunctionBlock("psico"));

		// Imprime el valor concreto de salida del sistema
		double TOC = fis.getVariable("toc").getLatestDefuzzifiedValue();
		double N_ansiedad = fis.getVariable("n_ansiedad").getLatestDefuzzifiedValue();

		return ("Se identifico un grado de TOC de: " + String.format("%.2f", TOC) + "\nSe identifico un nivel de ansiedad de: "
				+ String.format("%.2f", N_ansiedad));
	}
}